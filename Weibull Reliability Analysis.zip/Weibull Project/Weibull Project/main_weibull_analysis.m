%%===========================================================================================================================
% Weibull Failure Analysis - Crude Oil Pump Mechanical Seal
% Author : Ruth Imaoyani Morgan
% Date : Friday 12th June, 2026.
% Toolboxes : Statistics and Machine Learning Toolbox
%============================================================================================================================
mkdir('C:\Users\Morgan Imaoyin Ruth\Documents\WeibullProject')
cd('C:\Users\Morgan Imaoyin Ruth\Documents\WeibullProject')
clear; clc; close all;
if ~exist('figures', 'dir'), mkdir('figures');end
if ~exist('data', 'dir'), mkdir('data');end
%% Simulation Parameters
%----------------------------------------------------------------------------------------------------------------------------
% Component : Single Cartridge Mechanical Pump
% Application : Centrifugal crude oil transfer pump
% Failure def : Leakage exceeding 10 drops per minute
% Data Source : 50 seal replacements over 36 months 
%----------------------------------------------------------------------------------------------------------------------------
beta_true = 2.5;
eta_true = 1000;
n = 50;
rng(42)
t_fail = eta_true * (-log(rand(n,1))).^(1/beta_true);
histogram(t_fail, 10)
xlabel('Failure Times (hours)')
ylabel('Number of Failures')
title('Simulated Failure Times')
%% Parameter 
% This signifies the Least Squares method
% Sort your failure times from smallest to largest
t_sorted = sort(t_fail);
n = length(t_sorted);
% Assign a cumulative failure probability to each failure time
i = (1:n)';
F = (i - 0.3)/(n + 0.4);
% Transform both axes
x = log(t_sorted);
y = log(log(1./(1-F)));
% Fit a straight line through the transformed points
p = polyfit(x, y, 1);
% Extract beta and eta
beta_ls = p(1);
eta_ls = exp(-p(2) / beta_ls);
fprintf('Least Squares Estimates:\n')
fprintf('Beta: %.4f\n', beta_ls)
fprintf('Eta: %.2f hours\n', eta_ls)
% This signifies the MLE method
phat = mle(t_fail, 'distribution', 'Weibull');
beta_mle = phat(2);
eta_mle = phat(1);
fprintf('MLE Estimates: \n')
fprintf('Beta: %.4f\n', beta_mle)
fprintf('Eta: %.2f hours\n', eta_mle)
% This shows how to compare both methods
fprintf('\n---Comparison---\n')
fprintf('True Beta: %.2f | LS: %.4f | MLE: %.4f\n', beta_true, beta_ls, beta_mle)
fprintf('True Eta: %.2f | LS: %.4f | MLE: %.4f\n', eta_true, eta_ls, eta_mle)
% This is for Weibull Probability Plot
figure;
scatter(x, y, 40, 'filled')
hold on
plot (x, polyval(p,x), 'r--', 'LineWidth', 1.5)
xlabel('ln(t)'); ylabel('ln(ln(1/(1-F)))')
title('Weibull Probability Plot')
legend('Data points', 'Fitted line')
grid on
%% Reliability Function Computation
%--------------------------------------------------------------------------------------------------------------------------
% This is for computing the core reliability functions
t = linspace(0.01, max(t_fail)*1.5, 500);
% Reliability Function
R = exp(-(t/eta_mle).^beta_mle);
% Cumulative Failure Probability
F_cdf = 1 - R;
% Probability Density Function
f = (beta_mle/eta_mle).*(t/eta_mle).^(beta_mle-1).*exp(-(t/eta_mle).^beta_mle);
% Hazard Rate Function
h = (beta_mle/eta_mle).*(t/eta_mle).^(beta_mle-1);
fprintf('R at t=0: %.4f (should be ~1.0)\n',R(1))
fprintf('R at t=eta: %.4f (should be ~0.368)\n', interp1(t, R, eta_mle))
fprintf('F at t=eta: %.4f (should be ~0.632)\n', interp1(t, F_cdf, eta_mle))
%% Reliability Dashboard
%--------------------------------------------------------------------------------------------------------------------------
fig_dashboard = figure('Position', [100 100 1200 800]);
% Reliability Function top left
subplot(2, 2, 1)
plot(t, R, 'b', 'LineWidth', 2)
xlabel('Time(hours)')
ylabel('R(t)')
title('Reliability Function')
grid on
% Cumulative Failure Probability top right
subplot(2, 2, 2)
plot(t, F_cdf, 'r', 'LineWidth', 2)
xlabel('Time(hours)')
ylabel('F(t)')
title('Cumulative Failure Probability')
grid on
% hold on signifies adding to the current plot rather than replacing it
hold on
xline(eta_mle, 'k--', '\eta(Characteristic Life)', 'LabelVerticalAlignment','bottom')
% Probability Density Function bottom left
subplot(2, 2, 3)
plot(t, f,'g', 'LineWidth', 2)
xlabel('Time(hours)')
ylabel('f(t)')
title('Failure Probability Density')
grid on
% Hazard Rate Function bottom right
subplot(2, 2, 4)
plot(t, h, 'm', 'LineWidth', 2)
xlabel('Time(hours)')
ylabel('h(t)')
title('Hazard Rate Function')
grid on
%% Reliability Key Matrix
%------------------------------------------------------------------------------------------------------------------------------------------
%MTTF
MTTF = eta_mle * gamma(1 + 1/beta_mle);
fprintf('MTTF: %.2f hours\n', MTTF)
% this is for BX Life (Percentile Life)
B10 = eta_mle * (-log(1 - 0.10))^(1/beta_mle);
B50 = eta_mle * (-log(1 - 0.50))^(1/beta_mle);
B1 = eta_mle * (-log (1 - 0.01))^(1/beta_mle);
fprintf('B1 Life: %.2f hours\n', B1)
fprintf('B10 Life: %.2f hours\n', B10)
fprintf('B50 Life: %.2f hours\n', B50)
% this is a confirmation line for B50
R_at_B50 = exp(-(B50/eta_mle)^beta_mle);
fprintf('R at B50: %.4f(should be 0.5000)\n', R_at_B50)
% Marking MTTF on the reliability curve
subplot(2,2,1)
plot(t, R, 'b', 'LineWidth', 2)
hold on
R_at_MTTF = exp(-(MTTF/eta_mle)^beta_mle);
plot(MTTF, R_at_MTTF, 'ro', 'MarkerSize', 8,'MarkerFaceColor', 'r' )
xline(MTTF, 'r--', 'MTTF', 'LabelVerticalAlignment', 'bottom')
% Marking B10 and B50 on the reliability curve
plot(B10, 0.90, 'gs', 'MarkerSize',8, 'MarkerFaceColor', 'g')
xline(B10, 'g--', 'B10', 'LabelVerticalAlignment','bottom')
xlabel('Time(hours)');ylabel('R(t)')
title('Reliability Function'); grid on
% this is a master title for the whole display
sgtitle(sprintf('Weibull Failure Analysis | \\beta = %.2f, \\eta = %.0f hrs', beta_mle, eta_mle))
%% Weibull Probability Plot
%-------------------------------------------------------------------------------------------------------------------------------
% Building Weibull Probability Plot
% Plot data points and fitted lines
fig_weibull_probability_plot = figure('Position', [100, 100, 800, 600]);
scatter(x,y,50,"blue","filled")
hold on
x_line = linspace(min(x), max(x), 200);
plot(x_line, polyval(p,x_line), 'r--', 'LineWidth', 2)
% Making readable axes
prob_levels= [0.10, 0.20, 0.50, 0.63, 0.90];
for k = 1:length(prob_levels)
    y_ref = log(log(1/(1-prob_levels(k))));
    yline(y_ref, 'k', sprintf('F=%.0f%%', prob_levels(k)*100),'LabelHorizontalAlignment','left', 'FontSize', 8)
end    
% Adding Confidence Bounds
n = length(x);
x_mean = mean(x);
SE_line = std(y - polyval(p,x))*sqrt(1/n + (x_line -x_mean).^2 / sum((x-x_mean).^2));
t_val = tinv(0.90, n-2);
upper = polyval(p,x_line) + t_val * SE_line;
lower = polyval(p, x_line) - t_val * SE_line;
plot(x_line, upper, 'r--', 'LineWidth', 1)
plot(x_line, lower, 'r--', 'LineWidth', 1)
fill([x_line, fliplr(x_line)], [upper,fliplr(lower)], 'r', 'FaceAlpha', 0.1, 'EdgeColor', 'none')
% Final Labeling and Formatting
xlabel('ln(t) Time(hours) on log scale', 'FontSize', 11)
ylabel('ln(ln(1/(1-F))) Cumulative Failure Probability', 'FontSize', 11)
title('Weibull Probability Plot', 'FontSize', 13, 'FontWeight','bold')
legend('Failure Data', 'Weibull Fit(LS)', '90% Confidence Bounds', 'Location','northwest')
grid on
annotation("textbox", [0.62 0.15 0.25 0.12], "String", sprintf('\\beta = %.3f\n\\eta = %.1f hrs', beta_ls, eta_ls, 'FitBoxToText', 'on', 'BackgroundColor','white', 'EdgeColor', 'black', 'FontSize', 10))
%% Environmental Consequence Scoring
%--------------------------------------------------------------------------------------------------------------------
% Assign severity level to each risk case
c_spill = 8;
c_vapor = 6;
c_fire = 9;
% With gross value 1, delegate weighted scores based on occurrence level
c_weighted = 0.5*c_spill + 0.3*c_vapor + 0.2*c_fire;
fprintf('Weighted Consequence Score: %.2f / 10\n', c_weighted)
c_equal_weight = (c_spill + c_vapor + c_fire) / 3;
fprintf('Equal weight score: %.2f\n', c_equal_weight)
fprintf('Weighted score: %.2f\n', c_weighted)
% Consequence factor increases over time or with system degradation
alpha = 1.3;
c_t = c_weighted * (t/eta_mle).^alpha;
% This plot shows a visualization of varying alpha values
fig_alpha_consequences_comparison = figure('Position',[100 100 900 550]);
alpha_values = [0.7, 1.0, 1.3, 2.0];
colors = {'b', 'g', 'r', 'm'};
for j = 1:length(alpha_values)
    c_test = c_weighted * (t/eta_mle).^alpha_values(j);
    c_test = min(c_test, 10);
    col = colors{j};
    plot(t, c_test, colors{j}, 'LineWidth', 2)
    hold on
end 
xlabel('Time(hours)', 'FontSize', 11)
ylabel('Consequence Score','FontSize', 11)
title('Effect of Alpha on Consequence Growth', 'FontSize', 12)
legend('\alpha = 0.7', '\alpha = 1.0', '\alpha = 1.3', '\alpha = 2.0', 'Location', 'northwest')
yline(10, 'k--', 'Maximum Score = 10', 'LabelHorizontalAlignment','left')
grid on
% Ensure cap does not exceed maximum score
c_t = min(c_t, 10);
idx_cap = find(c_t >= 10, 1, 'first');
if ~isempty(idx_cap)
    fprintf('Consequence reaches maximum at t = %.1f hours\n', t(idx_cap))
else
    fprint('Consequence never reaches maximum within time range\n')
end
t_check = [B10, MTTF, B50];
labels = {'B10 (10% failed)', 'MTTF', 'B50 (50% failed)'};
fprintf('\n--- Consequence at Key Time Points ---\n')
for k = 1:length(t_check)
    c_val = c_weighted* (t_check(k)/eta_mle)^alpha;
    c_val = min(c_val, 10);
    fprintf('%-25s (t = %6.1f hrs): c = %.3f\n', labels{k}, t_check(k), c_val)
end
%% Risk Computation
Risk = F_cdf.*c_t;
fprintf('\n--- Risk at Key Time Points ---\n')
t_check = [B10, MTTF, B50];
labels = {'B10', 'MTTF', 'B50'};
for k = 1:length(t_check)
    [~, idx] = min(abs(t - t_check(k)));
    fprintf('%-6s (t = %6.1f hrs): F = %.3f | c = %.3f | Risk = %.4f\n', labels{k}, t_check(k), F_cdf(idx), c_t(idx), Risk(idx))
end 
% Here we normalize the risk
Risk_normalised = Risk/max(Risk);
fprintf('\n--- Risk Curve Verification ---\n')
fprintf('Risk at t~0 : %.6f (expect ~0)\n', Risk_normalised(1))
is_monotonic = all(diff(Risk_normalised)>= 0);
fprintf('Monotonically increasing: %d (expect 1)\n', is_monotonic)
fprintf('Maximum Risk value: %.6f(expect 1.0000)\n',max(Risk_normalised))
%% Risk Threshold Analysis
%---------------------------------------------------------------------------------------------------------------------------------------------
% Setting threshold values for low, medium and high risk zones (bath curve)
risk_low = 0.25;
risk_moderate = 0.60;
fprintf('\n--- Risk Zone Definitions ---\n')
fprintf('Green Zone (Risk <%.2f): Acceptable\n', risk_low)
fprintf('Response: Standard scheduled maintenance, routine monitoring\n\n')
fprintf('Yellow Zone (%.2f <= Risk < %.2f) :  Elevated\n', risk_low, risk_moderate)
fprintf('Response: Increase inspection frequency, prepare replacement perts\n')
fprintf('Scheduled maintenance window within next operating cycle\n\n')
fprintf('Red Zone (Risk >= %.2f) : Unacceptable\n', risk_moderate)
fprintf('Response: Immediate maintenance intervention required\n')
fprintf('Do not defer beyond this point\n')
% Time when risk enters yellow zone
idx_yellow = find(Risk_normalised >= risk_low, 1, 'first');
t_yellow = t(idx_yellow);
% Time when risk enters red zone
idx_red = find(Risk_normalised >= risk_moderate, 1, 'first');
t_red = t(idx_red);
fprintf('\n--- Zone Transition Times ---\n')
fprintf('Enters Yellow Zone at :%.1f hours\n', t_yellow)
fprintf('Enters Red Zone at :%.1fhours\n', t_red)
fprintf('Maintenance Window :%.1fhours(between yellow and red)\n', t_red-t_yellow)
% Deciding the best intervention time
idx_intervention = find(Risk_normalised >= risk_moderate, 1, "first");
t_intervention = t(idx_intervention);
fprintf('\n Recommended Intervention Time : %.1fhours\n', t_intervention)
% What reliability means at intervention time
R_at_intervention = exp(-(t_intervention/eta_mle)^beta_mle);
F_at_intervention = 1 - R_at_intervention;
% what percentile life does this intervention occur
B_percentile = F_at_intervention * 100;
fprintf('\n--- Intervention Context ---\n')
fprintf('Intervention at t: %.1f hours\n', t_intervention)
fprintf('Reliability remaining :%.1f%%\n', R_at_intervention * 100)
fprintf('Cumulative failure probability: %.1f%%\n', F_at_intervention * 100)
fprintf('Corresponds to B%.0f life\n', round(B_percentile))
fprintf('Time before MTTF : %.1f hours\n', MTTF - t_intervention)
fprintf('Time before B50: %.1f hours\n', B50 - t_intervention)
%% Environmental Risk Overlay Plot
%-----------------------------------------------------------------------------------------------------------------------------------------------------
fig_environmental_risk_overlay = figure('Position', [100 100 1000 600]);
hold on
fill([t, fliplr(t)], [min(Risk_normalised, risk_low), fliplr(zeros(1, length(t)))], [0.6 1.0 0.6], 'FaceAlpha', 0.25, 'EdgeColor', 'none')
fill([t, fliplr(t)], [min(Risk_normalised, risk_moderate), fliplr(min(Risk_normalised, risk_low))], [1.0 1.0 0.5], 'FaceAlpha', 0.25,'EdgeColor','none')
fill([t, fliplr(t)], [Risk_normalised, fliplr(min(Risk_normalised, risk_moderate))],[1.0 0.6 0.6], 'FaceAlpha', 0.25, 'EdgeColor', 'none')
plot(t, Risk_normalised, 'k', 'LineWidth', 2.5)
yline(risk_low, 'g-', 'Low Risk Threshold', 'LineWidth', 2, 'LabelHorizontalAlignment','left', 'LabelVerticalAlignment','bottom', 'FontSize',9)
yline(risk_moderate, 'r-', 'Moderate Risk Threshold', 'LineWidth', 2, 'LabelHorizontalAlignment','left', 'LabelVerticalAlignment','bottom', 'FontSize',9)
xline(t_yellow, 'g--', sprintf('Elevated Risk\nt = %.0f hrs', t_yellow), 'LineWidth', 1.5, 'LabelVerticalAlignment', 'top', 'FontSize', 9)
plot(t_yellow, risk_low, 'gs', 'MarkerSize', 10, 'MarkerFaceColor','g')
xline(t_red, 'r--', sprintf('Intervene by\nt = %.0f hrs', t_red), 'LineWidth', 1.5, 'LabelVerticalAlignment', 'top', 'FontSize', 9)
plot(t_red, risk_moderate, 'r^', 'MarkerSize', 10, 'MarkerFaceColor','r')
% Labeling the Plot
xlabel('Operating Time (hours)', 'FontSize', 12)
ylabel('Normalised Environmental Risk', 'FontSize', 12)
title({'Environmental Risk Overlay - Crude Oil Pump Mechanical Seal'; sprintf('\\beta=%.2f | \\eta = %.0f hrs | Intervention at %.0f hrs', beta_mle, eta_mle, t_red)}, 'FontSize', 12, 'FontWeight', 'bold')
legend('Acceptable Zone', 'Elevated Zone', 'Unacceptable Zone', 'Risk(t) = F(t) \ times c(t)', 'Location','northwest', 'FontSize', 9)
ylim([0 1.05])
grid on 
box on
%% Combined Reliability and Risk Chart
%---------------------------------------------------------------------------------------------------------------------------------------------
fig_reliability_risk_chart = figure('Position', [100 100 1000 600]);
yyaxis left
plot(t, R, 'b-', 'LineWidth', 2.5)
ylabel('Reliability R(t)', 'FontSize', 12, 'Color','b')
ylim([0 1.05])
yticks(0:0.1:1)
ax = gca;
ax.YColor = 'b';
yyaxis right
plot(t, Risk_normalised, 'r-', 'LineWidth', 2.5)
ylabel('Normalised Environmental Risk', 'FontSize', 12, 'Color','r')
ylim([0 1.05])
yticks(0:0.1:1)
ax = gca;
ax.YColor = 'r';
hold on
yline(risk_low, 'g--', 'LineWidth', 1.2)
yline(risk_moderate, 'r--', 'LineWidth', 1.2)
xline(B10, 'b:', sprintf('B10\n%.0f hrs', B10), 'LineWidth', 1.5, 'FontSize', 8, 'LabelVerticalAlignment','bottom', 'LabelHorizontalAlignment','right')
xline(MTTF, 'b--', sprintf('MTTF\n%.0f hrs', MTTF), 'LineWidth', 1.5, 'FontSize', 8, 'LabelVerticalAlignment','bottom', 'LabelHorizontalAlignment','right')
xline(t_red, 'r-', sprintf('Risk\nThreshold\n%.0f hrs', t_red), 'LineWidth', 2, 'FontSize', 8, 'LabelVerticalAlignment','bottom', 'LabelHorizontalAlignment','left')
yyaxis right
[~, iy] = min(abs(t - t_yellow));
plot(t_yellow, Risk_normalised(iy),'gs', 'MarkerSize', 12, 'MarkerFaceColor', 'g', 'LineWidth', 1.5)
[~, ir] = min(abs(t - t_red));
plot(t_red, Risk_normalised(ir),'r^', 'MarkerSize', 12, 'MarkerFaceColor', 'r', 'LineWidth', 1.5)
annotation('textbox', [0.13 0.15 0.28 0.22], 'String', {sprintf('\\beta = %.3f', beta_mle), sprintf('\\eta =%.0f hrs', eta_mle), sprintf('MTTF = %.0f hrs', MTTF), sprintf('B10 = %.0f hrs', B10), sprintf('Intervene by %.0fhrs', t_red)}, 'FitBoxToText','on','BackgroundColor','white', 'EdgeColor', 'black','FontSize', 9, 'FontName', 'Courier')
xlabel('Operating Time (hours)','FontSize', 12)
title({'Reliability vs Environmental Risk - Decision Support Chart'; 'Crude Oil Transfer Pump Mechanical Seal'}, 'FontSIze', 12, 'FontWeight', 'bold')
legend({'Reliability R(t)', 'Environmental Risk'}, "Location","north", 'FontSize',10, 'Orientation','horizontal')
grid on
box on
%% Export Figures and Data
%---------------------------------------------------------------------------------------------------------------------------------
if ~exist('figures' , 'dir'), mkdir('figures'); end
if ~exist('data', 'dir'), mkdir('data'); end
% This exports figures
fig_dashboard.PaperPositionMode = 'auto';
print(fig_dashboard, 'figures/dashboard', '-dpng', '-r300')
fprintf ('Exported: figures/dashboard.png\n')
   
fig_alpha_consequences_comparison.PaperPositionMode = 'auto';
print(fig_alpha_consequences_comparison, 'figures/alpha_consequences_comparison' , '-dpng', '-r300')
fprintf ('Exported: figures/alpha_consequences_comparison.png\n')
    
fig_weibull_probability_plot.PaperPositionMode = 'auto';
print(fig_weibull_probability_plot, 'figures/weibull_probability_plot', '-dpng', '-r300')
fprintf ('Exported: figures/weibull_probability_plot.png\n')
    
fig_environmental_risk_overlay.PaperPositionMode = 'auto';
print(fig_environmental_risk_overlay, '-dpng', '-r300')
fprintf ('Exported: figures/environmental_risk_overlay.png\n')
    
fig_reliability_risk_chart.PaperPositionMode = 'auto';
print(fig_reliability_risk_chart, '-dpng', '-r300')
fprintf ('Exported: figures/reliability_risk_chart.png\n')

% This exports data
T_failure = table(t_fail, 'VariableNames', {'FailureTime_hrs'});
writetable(T_failure, 'data/simulated_failure_data.csv')
fprintf('Exported: data/simulated_failure_data.csv\n')

T_results = table(t, R, F_cdf, f, h, c_t, Risk, Risk_normalised, 'VariableNames',{'Time_hrs', 'Reliability', 'CDF', 'PDF', 'Hazard_Rate', 'Consequence', 'Raw_Risk', 'Normalised_Risk'});
writetable(T_results, 'data/reliability_results.csv')
fprintf('Exported: data/reliability_results.csv\n')

% This exports key metrics

b_mle = beta_mle(1);
e_mle = eta_mle(1);
b_ls = beta_ls(1);
e_ls = eta_ls(1);
mttf = MTTF(1);
b1 = B1(1);
b10 = B10(1);
b50 = B50(1);
t_yel = t_yellow(1);
t_rd = t_red(1);

metrics = {'Beta (MLE)',  b_mle;
          'Eta (MLE)',   e_mle;
          'Beta (LS)',   b_ls;
          'Eta (LS)',    e_ls;
          'MTTF',        mttf;
          'B1 Life',     b1;
          'B10 Life',    b10;
          'B50 Life',    b50;
          'Yellow Zone Entry (hrs)', t_yel;
          'Red Zone Entry (hrs)', t_rd};
T_metrics = cell2table(metrics, 'VariableNames', {'Metric', 'Value'});
writetable(T_metrics, 'data/metrics_summary.csv')
fprintf('Exported: data/metrics_summary.csv\n')
%% Final Console Summary
%--------------------------------------------------------------------------------------------------------------------------------------------------
fprintf('\n')
fprintf('WEIBULL FAILURE ANALYSIS\n')
fprintf('Component: Crude Oil Pump Mechanical Seal\n')
fprintf('\n')
fprintf('--- Parameter Estimates ---\n')
fprintf('Beta (MLE) : %.4f\n', beta_mle)
fprintf('Eta (MLE) : %.2f hours\n', eta_mle)
fprintf('Beta (LS) : %.4f\n', beta_ls)
fprintf('Beta (LS) : %.2f hours\n', eta_ls)
fprintf('\n')
fprintf('--- Life Metrics ---\n')
fprintf('MTTF: %.2f hours\n', MTTF)
fprintf('B1 Life: %.2f hours\n', B1)
fprintf('B10 Life: %.2f hours\n', B10)
fprintf('B50 Life: %.2f hours\n', B50)
fprintf('\n')
fprintf('--- Environmental Risk ---\n')
fprintf('Conequence Score: %.2f / 10\n', c_weighted)
fprintf('Yellow Zone Entry: %.1f hours\n', t_yellow)
fprintf('Red Zone Entry: %.1f hours\n', t_red)
fprintf('Maintenance Window: %.1f hours\n', t_red - t_yellow)
fprintf('\n')
fprintf('--- Export Status ---\n')
fprintf('Figures saved to: /figures\n')
fprintf('Data saved to: /data\n')
fprintf('\n')
fprintf('Analysis complete.\n')
fprintf('\n')